# ROYAL PALACE

카지노 호텔 VIP 라운지 콘셉트의 게임 사이트. 외부 라이브러리 없이 Node.js 내장 모듈만 사용합니다.
(가상 코인으로만 즐기는 게임이며 실제 금전과 무관합니다.)

## 실행
```bash
npm start        # 또는 node server.js
```
`http://localhost:3000` 접속 (포트 변경: `PORT=8080 npm start`). Node 18 이상 필요.

## 파일 구조 (모두 루트에 두면 됩니다)
| 파일 | 설명 |
|---|---|
| `server.js` | 회원가입·로그인, 게임 API, 저장소 처리 |
| `index.html` | 로그인 / 회원가입 화면 |
| `lobby.html` | 로비 (LUCK 실력 무관 / SKILL 실력 관련, 내 기록) |
| `roulette.html` | 777 룰렛 슬롯머신 (LUCK 카테고리) |
| `theme.css`, `app.js` | 모든 페이지 공통 디자인 / 공통 스크립트 |

새 게임을 추가할 때는 `roulette.html`처럼 페이지를 만들고, `server.js`의 `PAGES`에 주소를 등록한 뒤
`lobby.html`의 게임 목록에 카드를 추가합니다. 로그인이 필요한 페이지는 `PROTECTED`에 넣으세요.

## 데이터 저장 (중요)
회원 정보, 코인, 게임 기록은 서버 저장소에 보관됩니다.

- **Render 무료 플랜의 파일은 재시작·재배포·15분 유휴 절전 때마다 초기화**됩니다.
  그래서 배포 환경에서는 [Upstash Redis](https://upstash.com) (무료)를 연결해야 기록이 유지됩니다.
- Render 서비스의 Environment에 아래 두 값을 추가하면 자동으로 Redis를 사용합니다.

| Key | Value |
|---|---|
| `UPSTASH_REDIS_REST_URL` | Upstash 데이터베이스의 REST URL |
| `UPSTASH_REDIS_REST_TOKEN` | Upstash 데이터베이스의 REST Token |

- 값이 없으면 `data/users.json` 파일에 저장합니다 (내 컴퓨터에서 테스트할 때용, Git에는 올라가지 않음).

## 777 룰렛 (슬롯머신)
| 결과 | 조건 | 확률 | 지급 |
|---|---|---|---|
| 777 잭팟 | 릴 3개 모두 7 | 1 / 777 | 베팅액 × 50 |
| 같은 모양 2개 | 어떤 모양이든 2개 (위치 무관) | 약 28% | 베팅액 × 3 |
| 꽝 | 세 릴이 모두 다른 모양 | 나머지 | 없음 |

- 가입하면 **1,000 코인**으로 시작, 베팅 10 ~ 100,000 코인 (코인이 10 미만이면 REFILL 1,000)
- 기대 환수율 약 90.3% (잭팟 6.4% + 같은 모양 2개 83.9%)
- 결과는 서버에서 `crypto.randomInt`로 정하고, 화면의 릴은 서버가 알려준 결과대로 멈춥니다.
- 같은 모양이 3개 나오는 경우는 777뿐입니다.
- 규칙 값은 `server.js` 맨 위의 `WIN_ODDS`, `PAYOUT_MULT`, `PAIR_MULT`, `PAIR_PERMILLE`(1000분율), `START_CHIPS`에서 바꿉니다.
  게임 규칙을 크게 바꿔 모두 처음부터 다시 시작하게 하려면 `GAME_VERSION` 숫자를 올리세요.

## 보너스 코인 지급
`server.js` 맨 위의 `GRANTS`에 `{ id, names, amount }`를 추가하면 해당 아이디가 로그인할 때 한 번만 코인을 받습니다.
(아이디에는 공백을 쓸 수 없습니다. 같은 `id`는 계정당 한 번만 지급됩니다.)

## API
| 메서드 | 경로 | 설명 |
|---|---|---|
| POST | `/api/register` | 회원가입 (성공 시 자동 로그인) |
| POST | `/api/login` | 로그인 |
| POST | `/api/logout` | 로그아웃 |
| GET | `/api/me`, `/api/profile` | 내 정보 · 칩 · 통계 · 최근 기록 |
| GET | `/api/roulette/config` | 확률 · 배율 · 베팅 한도 |
| POST | `/api/roulette/spin` | 스핀 `{ "bet": 100 }` → `{ reels, win, payout, delta, chips }` |
| POST | `/api/refill` | 코인이 10 미만일 때 1,000코인 충전 |

## 규칙 / 보안
- 아이디: 글자·숫자·`_` (숫자만도 가능, 길이 제한 없음, 공백 불가) / 비밀번호: 영문+숫자 포함 8~64자
- 비밀번호는 scrypt + salt로 해시, 세션 쿠키는 HttpOnly + SameSite=Strict
- 허용 목록의 파일만 제공하므로 `server.js`, `data/` 등은 외부에 노출되지 않습니다.
- 세션은 서버 메모리에 있어서 서버가 재시작되면 다시 로그인해야 합니다 (코인·기록은 유지).
